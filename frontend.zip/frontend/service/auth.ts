import api from './axios';

export const authApi = {
    login: async (data: any) => {
        const response = await api.post('/auth/login', data);
        return response.data;
    },
    register: async (data: any) => {
        const response = await api.post('/auth/register', data);
        return response.data;
    },
    refreshToken: async (refreshToken: string) => {
        try {
            const response = await api.post('/auth/refresh', { refresh_token: refreshToken });
            
            const responseData = response.data.data || response.data;
            
            if (!responseData.access_token) {
                console.warn("[auth] No access_token in refresh response. Response:", response.data);
                throw new Error("No access_token in refresh response");
            }

            // Check if refresh token is expired (7 days)
            if (responseData.refresh_token_expires_at) {
                const expiryTime = new Date(responseData.refresh_token_expires_at).getTime();
                const now = new Date().getTime();
                if (expiryTime < now) {
                    console.error("[auth] Refresh token has expired");
                    throw new Error("Refresh token has expired");
                }
            }

            console.log("[auth] Token refreshed successfully");
            return responseData;
        } catch (error: any) {
            const errorMsg = error.response?.data?.message || error.message || "Unknown error";
            console.error("[auth] Token refresh error:", errorMsg);
            throw error;
        }
    },
};