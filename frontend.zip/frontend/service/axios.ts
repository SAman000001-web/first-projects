import axios from 'axios';

const api = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000',
    // headers: {
    //     'Content-Type': 'application/json',
    // },
});

let isRefreshing = false;
let failedQueue: any[] = [];// Queue to hold failed requests while token is being refreshed

// Funtion to procees the failed requests after token is refreshed
const processQueue = (error: any, token: string | null = null) => {
  failedQueue.forEach(prom => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  failedQueue = [];
};

// Request Interceptor (Attach Token)
api.interceptors.request.use(
  (config) => {
    if (typeof window !== "undefined") {
      const token = localStorage.getItem("token");
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor (Handle 401 & Refresh)
api.interceptors.response.use(

  (response) => response,
  
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        })
          .then(token => {
            originalRequest.headers['Authorization'] = `Bearer ${token}`;
            return api(originalRequest);
          })
          .catch(err => Promise.reject(err));
      }

      isRefreshing = true;
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem("refresh_token");
        if (!refreshToken) {
          throw new Error("No refresh token");
        }

        const base = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
        const response = await axios.post(`${base}/auth/refresh`, { refresh_token: refreshToken });
        const newAccessToken = response?.data?.access_token;

        if (!newAccessToken || typeof newAccessToken !== 'string') {
          throw new Error(`Invalid access token received: ${newAccessToken}`);
        }

        console.log(`[token refresh] ${new Date().toISOString()} - axios refreshed access token`);

        // Store new tokens
        localStorage.setItem("token", newAccessToken);
        if (response.data.refresh_token) {
          localStorage.setItem("refresh_token", response.data.refresh_token);
        }
        if (response.data.refresh_token_expires_at) {
          localStorage.setItem("refresh_token_expires_at", response.data.refresh_token_expires_at);
        }
        
        api.defaults.headers.common['Authorization'] = `Bearer ${newAccessToken}`;
        originalRequest.headers['Authorization'] = `Bearer ${newAccessToken}`;

        processQueue(null, newAccessToken);
        return api(originalRequest);
      } catch (err) {
        console.error("[token refresh] Error refreshing token:", err);
        processQueue(err, null);
        localStorage.removeItem("token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("refresh_token_expires_at");
        window.location.href = "/login";
        return Promise.reject(err);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

export default api;