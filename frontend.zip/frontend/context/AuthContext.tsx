"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { jwtDecode } from "jwt-decode";
import { authApi } from "@/service/auth";

interface User {
  userId: string;
  email: string;
  role: string;
  name: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (
    token: string,
    refreshToken: string,
    refreshTokenExpiresAt?: string,
  ) => void;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState<any>(null);
  const router = useRouter();

  const refreshAccessToken = async () => {
    try {
      const refreshToken = localStorage.getItem("refresh_token");
      if (!refreshToken) {
        console.warn("[auth] No refresh token found, logging out");
        logout();
        return false;
      }

      // Validate refresh token expiration before attempting refresh
      const refreshTokenExpiry = localStorage.getItem(
        "refresh_token_expires_at",
      );
      if (refreshTokenExpiry) {
        const expiryTime = new Date(refreshTokenExpiry).getTime();
        const now = new Date().getTime();
        if (expiryTime < now) {
          console.warn("[auth] Refresh token has expired, logging out");
          logout();
          return false;
        }
      }

      const response = await authApi.refreshToken(refreshToken);
      const newAccessToken = response?.access_token;

      if (!newAccessToken || typeof newAccessToken !== "string") {
        console.error("[auth] Invalid access token received:", newAccessToken);
        logout();
        return false;
      }

      localStorage.setItem("token", newAccessToken);
      if (response.refresh_token) {
        localStorage.setItem("refresh_token", response.refresh_token);
      }
      if (response.refresh_token_expires_at) {
        localStorage.setItem(
          "refresh_token_expires_at",
          response.refresh_token_expires_at,
        );
      }

      setToken(newAccessToken);

      try {
        const decoded: any = jwtDecode(newAccessToken);
        setUser({
          userId: decoded.sub,
          email: decoded.email,
          role: decoded.role,
          name: decoded.name,
        });
      } catch (decodeError) {
        console.error("[auth] Failed to decode new token:", decodeError);
        logout();
        return false;
      }

      console.log(
        `[auth] ${new Date().toISOString()} - Token refreshed successfully`,
      );
      return true;
    } catch (error: any) {
      const errorMsg =
        error.response?.data?.message || error.message || "Unknown error";
      console.error(
        `[auth] ${new Date().toISOString()} - Failed to refresh token:`,
        errorMsg,
      );

      return false;
    }
  };

  const startRefreshTimer = () => {
    if (refreshInterval) clearInterval(refreshInterval);
    console.log("[auth] Starting token refresh timer (10 minutes)");
    const interval = setInterval(
      () => {
        refreshAccessToken();
      },
      10 * 60 * 1000,
    );
    setRefreshInterval(interval);
  };

  useEffect(() => {
    const storedToken = localStorage.getItem("token");
    if (storedToken) {
      try {
        const decoded: any = jwtDecode(storedToken);
        setToken(storedToken);

        setUser({
          userId: decoded.sub,
          email: decoded.email,
          role: decoded.role,
          name: decoded.name,
        });

        startRefreshTimer();
      } catch (error) {
        console.error("Failed to decode stored token:", error);
        localStorage.removeItem("token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("refresh_token_expires_at");
      }
    }
    setLoading(false);

    return () => {
      if (refreshInterval) clearInterval(refreshInterval);
    };
  }, []);

  const login = (
    newToken: string,
    refreshToken: string,
    refreshTokenExpiresAt?: string,
  ) => {
    if (!newToken || typeof newToken !== "string") {
      console.error("Invalid token provided to login:", newToken);
      return;
    }

    try {
      const decoded: any = jwtDecode(newToken);

      localStorage.setItem("token", newToken);
      localStorage.setItem("refresh_token", refreshToken);

      if (refreshTokenExpiresAt) {
        localStorage.setItem("refresh_token_expires_at", refreshTokenExpiresAt);
      } else {
        const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
        localStorage.setItem(
          "refresh_token_expires_at",
          expiresAt.toISOString(),
        );
        console.log("Refresh token expires in 7 days");
      }

      setToken(newToken);

      const role = decoded.role?.toUpperCase();

      setUser({
        userId: decoded.sub,
        email: decoded.email,
        role: role,
        name: decoded.name,
      });

      startRefreshTimer();

      const rolePaths: Record<string, string> = {
        ADMIN: "/admin",
        OWNER: "/owner",
        CUSTOMER: "/customer",
      };

      const redirectPath = rolePaths[role] || "/login";

      console.log("User logged in, redirecting to:", redirectPath);

      setTimeout(() => {
        router.push(redirectPath);
      }, 0);
    } catch (error) {
      console.error("Failed to decode token during login:", error);
      logout();
    }
  };

  const logout = () => {
    console.log("User logging out");
    localStorage.removeItem("token");
    localStorage.removeItem("refresh_token");
    localStorage.removeItem("refresh_token_expires_at");
    if (refreshInterval) clearInterval(refreshInterval);
    setToken(null);
    setUser(null);
    router.push("/login");
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
