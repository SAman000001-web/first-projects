"use client";

import React, { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";

interface PublicRouteProps {
  children: React.ReactNode;
}

export const PublicRoute: React.FC<PublicRouteProps> = ({ children }) => {
  const { user, token, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;

    if (token && user) {
      const rolePaths: Record<string, string> = {
        ADMIN: "/admin",
        OWNER: "/owner",
        CUSTOMER: "/customer",
      };
      const redirectPath = rolePaths[user.role] || "/";
      router.push(redirectPath);
      return;
    }
  }, [user, token, loading, router]);

  if (loading) {
    return (
      <div>
        <p>Loading...</p>
      </div>
    );
  }

  if (token && user) {
    return null;
  }

  return <>{children}</>;
};
