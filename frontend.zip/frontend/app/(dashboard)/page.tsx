import { useAuth } from "@/context/AuthContext";

export default function Dashboard() {
  const { user } = useAuth();
  return (
    <div className="w-full max-w-2xl text-center bg-white shadow rounded p-8">
      <h1 className="text-2xl font-semibold mb-4">Dashboard</h1>
      {user?.role === "admin" && <p>Welcome, Admin!</p>}
      {user?.role === "owner" && <p>Welcome, Owner!</p>}
      {user?.role === "customer" && <p>Welcome, Customer!</p>}
    </div>
  );
}
